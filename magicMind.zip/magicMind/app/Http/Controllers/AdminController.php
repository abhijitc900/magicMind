<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use App\Models\Registration;
use App\Models\Todo;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Auth;

class AdminController extends Controller
{

    public function loginUser(Request $request)
    {

        $request->validate([
            'email'    => 'required',
            'password' => 'required',
        ]);
        $email    = $request->email;
        $password = $request->password;
        $details  = Registration::where('reg_email', $email)->where('reg_status', 1)->first();
        if (!$details) {
            return redirect('/admin')->with('failed', 'This email not in our user credential');
        }
        $mainPassword = $details->reg_password;

        if (Hash::check($password, $mainPassword)) {
            Session::put('user_id', $details->reg_id);
            return redirect('/dashboard')->with('success', 'Login Successfully');
        } else {
            return redirect('/admin')->with('failed', 'Login Failed!!');
        }
    }

    public function formAdd(Request $request)
    {
        // Validation rules
        $validator = Validator::make($request->all(), [
            'todoDate' => 'required',
            'title'    => 'required',
            'description'   => 'required',
        ]);

        // Check for validation errors
        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 422);
        }
        // Proceed if validation passes
        $userId = Session::get('user_id');
        if ($userId == NULL || $userId == '') {
            return redirect('/admin')->with('failed', 'Unauthorized Authentication');
        }
        $todoDate = $request->input('todoDate');
        $title    = $request->input('title');
        $description = $request->input('description');


        $master                   = new Todo();
        $master->todo_reg_id = $userId;
        $master->todo_date =  date("Y-m-d", strtotime($todoDate));
        $master->todo_title    = $title;
        $master->todo_details   = $description;
        if ($master->save()) {
            return response()->json(['success' => 'Add successfully']);
        } else {
            return response()->json(['error' => 'Data not insert']);
        }
    }

    public function getMasterList()
    {

        $userId = Session::get('user_id');
        if ($userId == NULL || $userId == '') {
            return redirect('/admin')->with('failed', 'Unauthorized Authentication');
        }
        $userData = DB::table('todo')
            ->where('todo.todo_status', '=', 1)
            ->where('todo.todo_reg_id', '=', $userId)
            ->orderBy('todo.todo_date', 'ASC')
            ->get();
        return view('/master', compact('userData'));
    }

    public function updateForm(Request $request)
    {
        $id       = $request->input('id');
        $userId = Session::get('user_id');
        if ($userId == NULL || $userId == '') {
            return redirect('/admin')->with('failed', 'Unauthorized Authentication');
        }
        $userData = DB::table('todo')
            ->where('todo.todo_status', '=', 1)
            ->where('todo.todo_reg_id', '=', $userId)
            ->where('todo.todo_id', '=', $id)
            ->first();
        return view('/updateForm', compact('userData'));
    }

    public function updateFormData(Request $request)
    {
        // Validation rules
        $validator = Validator::make($request->all(), [
            'todoDate' => 'required',
            'title'    => 'required',
            'description'   => 'required',
        ]);

        // Check for validation errors
        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 422);
        }
        $userId = Session::get('user_id');
        if ($userId == NULL || $userId == '') {
            return redirect('/admin')->with('failed', 'Unauthorized Authentication');
        }
        // Proceed if validation passes
        $id      = $request->input('id');
        $todoDate = $request->input('todoDate');
        $title    = $request->input('title');
        $description = $request->input('description');

        $setMasterData       = array(
            'todo_date' =>  date("Y-m-d", strtotime($todoDate)),
            'todo_title'    => $title,
            'todo_details'   => $description,
        );
        $respondeData        = Todo::where('todo_id', $id)->update($setMasterData);
        if ($respondeData) {
            return response()->json(['success' => 'Add successfully']);
        } else {
            return response()->json(['error' => 'Data not insert']);
        }
    }

    public function deleteData(Request $request)
    {
        $id                  = $request->input('id');
        $userId              = Session::get('user_id');
        $respondeDetailsData = Todo::where('todo_id', $id)->update(['todo_status' => 0]);
        if ($respondeDetailsData) {
            return redirect('/todo')->with('success', 'Delete Successfully');
        } else {
            return redirect('/todo')->with('failed', 'Delete Failed!!');
        }
    }

    public function logout()
    {
        $userId = Session::get('user_id');
        Session::flush();
        Auth::logout();
        return redirect('admin')->with('success', 'Logout Successfully');
    }

    public function completeTodo(Request $request)
    {
        $todo_id = $request->todo_id;
        $data = Todo::where('todo_id', $todo_id)->first();
        if ($data->todo_complete == 1) {
            $status = 0;
            $msg = 'Todo mark incomplete';
        } else {
            $status = 1;
            $msg = 'Todo mark complete';
        }
        $data = DB::table('todo')
            ->where('todo_id', $todo_id)
            ->update(['todo_complete' => $status]);
        if ($data) {
            return response()->json(['success' => $msg]);
        }
    }
}
