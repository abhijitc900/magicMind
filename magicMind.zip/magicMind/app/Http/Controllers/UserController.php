<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use App\Models\Registration;
use Illuminate\Support\Facades\DB;

class UserController extends Controller
{

    public function createRegistration(Request $request)
    {
        // Validation rules
        $validator = Validator::make($request->all(), [
            'name'   => 'required',
            'email'  => 'required|email',
            'phone'  => 'required', // Ensures the phone number is unique in the 'users' table
            'dob'    => 'required|date',
            'gender' => 'required',
            'password' => 'required',
        ]);

        // Check for validation errors
        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 422);
        }
        // Proceed if validation passes
        $name        = $request->input('name');
        $email       = $request->input('email');
        $phone       = $request->input('phone');
        $dob         = $request->input('dob');
        $gender      = $request->input('gender');
        $password      = $request->input('password');
        $countEmail = Registration::where('reg_email', $email)->get();
        if (count($countEmail) > 0) {
            return response()->json(['error' => 'Email already exist']);
        }

        $user             = new Registration();
        $user->reg_name   = $name;
        $user->reg_email  = $email;
        $user->reg_phone  = $phone;
        $user->reg_dob    = date("Y-m-d", strtotime($dob));
        $user->reg_gender = $gender;
        $user->reg_password = bcrypt($password);

        $user->save();
        return response()->json(['success' => 'Registration created successfully']);
    }

    public function getList()
    {

        $userData = DB::table('registration')->select(
            'reg_id',
            'reg_name',
            'reg_email',
            'reg_phone',
            'reg_dob',
            'reg_created_at',
            DB::raw("(CASE WHEN reg_gender='1' THEN 'Female' WHEN reg_gender='2' THEN 'Male' ELSE 'Other' END) as gender")
        )
            ->orderBy('reg_id', 'DESC')
            ->get();
        return view('/list', compact('userData'));
    }
}
