<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Activity Log List</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    </head>
    <body>
        <?php echo $__env->make("layout/header-top", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="my-container">
            <h1>Activity Log List</h1>
            <?php if(session('success')): ?>
            <div class="alert-success">
                <?php echo e(session('success')); ?>

            </div>
            <?php endif; ?>

            <?php if(session('failed')): ?>
            <div class="alert-danger">
                <?php echo e(session('failed')); ?>

            </div>
            <?php endif; ?>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Title</th>
                        <th scope="col">Description</th>
                        <th scope="col">Created At</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1;?>
                    <?php $__currentLoopData = $logData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($i); ?></th>
                        <td><?php echo e($log->log_title); ?></td>
                        <td><?php echo e($log->log_description); ?></td>
                        <td><?php echo e(date("d-m-Y H:i:s", strtotime($log->log_created_at))); ?></td>
                    </tr>
                    <?php $i++;?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
            <script>
$(document).ready(function () {
    // Attach click event to delete links
    $('.delete-link').click(function (e) {
        e.preventDefault();

        // Get the user ID from the data-id attribute
        var userId = $(this).data('id');

        // Display confirmation dialog
        var isConfirmed = confirm("Are you sure you want to delete this master?");

        // If user confirms, navigate to the delete URL
        if (isConfirmed) {
            window.location.href = "<?php echo e(url('/deleteData')); ?>?id=" + userId;
        }
    });
});
            </script>
        </div>
    </body>
</html><?php /**PATH D:\webguru\webguru\resources\views//activity.blade.php ENDPATH**/ ?>