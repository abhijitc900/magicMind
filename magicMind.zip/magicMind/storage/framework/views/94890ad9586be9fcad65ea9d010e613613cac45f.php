<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Todo List</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>

<body>
    <?php echo $__env->make("layout/header-top", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="my-container">
        <h1>Todo List</h1>
        <?php if(session('success')): ?>
        <div class="alert-success">
            <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>

        <?php if(session('failed')): ?>
        <div class="alert-danger">
            <?php echo e(session('failed')); ?>

        </div>
        <?php endif; ?>


        <div class="pull-right" style="float:right;margin: 0 10px 5px 0">
            <a href="<?php echo e(url('/addForm')); ?>" class="btn btn-info" role="button">Add</a>
        </div>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Date</th>
                    <th scope="col">Title</th>
                    <th scope="col">Description</th>
                    <th scope="col">Created At</th>
                    <th scope="col">Mark Complete</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody id="first_tbody">
                <?php $i = 1;?>
                <?php $__currentLoopData = $userData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($i); ?></th>
                    <td><?php echo e(date("d-m-Y", strtotime($user->todo_date))); ?></td>
                    <td><?php echo e($user->todo_title); ?></td>
                    <td><?php echo e($user->todo_details); ?></td>
                    <td><?php echo e(date("d-m-Y H:i:s", strtotime($user->todo_created_at))); ?></td>
                    <td><input type="checkbox" name="to_do" id="to_do" value="<?php echo e($user->todo_id); ?>" onchange="completeTodo(this.value)" <?php echo e($user->todo_complete === 1 ? "checked" : ""); ?>></td>
                    <td><a href="<?php echo e(url('/updateForm')); ?>?id=<?php echo e($user->todo_id); ?>">Edit</a>&nbsp;&nbsp;<a href="#" class="delete-link" data-id="<?php echo e($user->todo_id); ?>">Delete</a></td>
                </tr>
                <?php $i++;?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
        <script>
            $(document).ready(function() {
                // Attach click event to delete links
                $('#first_tbody').on('click', '.delete-link', function(e) {
                    e.preventDefault();
                    // Get the user ID from the data-id attribute
                    var userId = $(this).data('id');

                    // Display confirmation dialog
                    var isConfirmed = confirm("Are you sure you want to delete this todo?");

                    // If user confirms, navigate to the delete URL
                    if (isConfirmed) {
                        window.location.href = "<?php echo e(url('/deleteData')); ?>?id=" + userId;
                    }
                });
            });

            function completeTodo(val) {

                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });

                $.ajax({
                    type: 'POST',
                    url: "<?php echo e(url('/completeTodo')); ?>",
                    data: {
                        todo_id: val

                    },
                    success: function(response) {
                        alert(response.success);
                    }
                });
            }
        </script>
    </div>
</body>

</html><?php /**PATH D:\magicMind\resources\views//master.blade.php ENDPATH**/ ?>