<div class="top-menu" style="background-color:#17a2b8; padding: 20px;">
    <div class="row">
        <div class="col-md-10">
            <a href="<?php echo e(url('/dashboard')); ?>"><img src="/logo.svg" alt="Logo" width="100" height="50" /></a>&nbsp;&nbsp;
            <a href="<?php echo e(url('/dashboard')); ?>" style="color: #fff; font-weight:bold;">Dashboard</a>&nbsp;&nbsp;
            <a href="<?php echo e(url('/todo')); ?>" style="color: #fff; font-weight:bold;">TODO</a>&nbsp;&nbsp;
        </div>
        <div class="col-md-2"> <a href="<?php echo e(url('/logout')); ?>" style="color: #fff; font-weight:bold;">Logout</a></div>
    </div>
</div><?php /**PATH D:\magicMind\resources\views/layout/header-top.blade.php ENDPATH**/ ?>