<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Master List</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    </head>
    <body>
        <div class="my-container">
            <h1>Master List</h1>
            <?php if(session('success')): ?>
            <div class="alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php if(session('failed')): ?>
            <div class="alert-danger">
                <?php echo e(session('failed')); ?>

            </div>
        <?php endif; ?>
            <div class="pull-right" style="float:right;margin: 0 10px 5px 0">
                <a href="<?php echo e(url('/addForm')); ?>" class="btn btn-info" role="button">Add</a>
            </div>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Flag Image</th>
                        <th scope="col">Country</th>
                        <th scope="col">City</th>
                        <th scope="col">Start IP</th>
                        <th scope="col">End IP</th>
                        <th scope="col">Created At</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1;?>
                    <?php $__currentLoopData = $userData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($i); ?></th>
                        <td><img src="<?php echo e('/flags/' . $user->mst_flag_image); ?>" alt="Example Image" width="100" height="100"></td>
                        <td><?php echo e($user->mst_country_name); ?></td>
                        <td><?php echo e($user->mst_city_name); ?></td>
                        <td><?php echo e($user->sec_start_ip); ?></td>
                        <td><?php echo e($user->sec_end_ip); ?></td>
                        <td><?php echo e(date("d-m-Y H:i:s", strtotime($user->mst_created_at))); ?></td>
                    </tr>
                    <?php $i++;?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

        </div>
    </body>
</html><?php /**PATH D:\laravel9\resources\views//dashboard.blade.php ENDPATH**/ ?>