<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Administrator List</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    </head>
    <body>
        <div class="my-container">
            <h1>Administrator List</h1>
            <div class="pull-right" style="float:right;margin: 0 10px 5px 0">
                <a href="<?php echo e(url('/admin')); ?>" class="btn btn-info" role="button">Log In</a>
            </div>
            <div class="pull-right" style="float:right;margin: 0 10px 5px 0">
                <a href="<?php echo e(url('/create')); ?>" class="btn btn-info" role="button">Sign In</a>
            </div>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Image</th>
                        <th scope="col">Name</th>
                        <th scope="col">Email</th>
                        <th scope="col">Phone</th>
                        <th scope="col">Date Of Birth</th>
                        <th scope="col">Gender</th>
                        <th scope="col">Created At</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1;?>
                    <?php $__currentLoopData = $userData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($i); ?></th>
                        <td><img src="<?php echo e('/uploads/' . $user->reg_file); ?>" alt="Example Image" width="100" height="100"></td>
                        <td><?php echo e($user->reg_name); ?></td>
                        <td><?php echo e($user->reg_email); ?></td>
                        <td><?php echo e($user->reg_phone); ?></td>
                        <td><?php echo e(date("d-m-Y", strtotime($user->reg_dob))); ?></td>
                        <td><?php echo e($user->gender); ?></td>
                        <td><?php echo e(date("d-m-Y H:i:s", strtotime($user->reg_created_at))); ?></td>
                    </tr>
                    <?php $i++;?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

        </div>
    </body>
</html><?php /**PATH D:\webguru\webguru\resources\views//list.blade.php ENDPATH**/ ?>