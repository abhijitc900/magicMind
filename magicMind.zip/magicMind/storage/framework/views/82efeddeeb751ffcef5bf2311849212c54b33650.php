<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Master List</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    </head>
    <body>
        <?php echo $__env->make("layout/header-top", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="my-container">
            <h1>Master List</h1>
            <?php if(session('success')): ?>
            <div class="alert-success">
                <?php echo e(session('success')); ?>

            </div>
            <?php endif; ?>

            <?php if(session('failed')): ?>
            <div class="alert-danger">
                <?php echo e(session('failed')); ?>

            </div>
            <?php endif; ?>


            <form>
                <div class="col-lg-9">
                    <div class="row align-items-center">
                        <div class="col-sm-auto">
                            <label class="" for="city">Location/City :</label>
                        </div>
                        <div class="col-sm-auto">
                            <input class="form-control" type="text" value="" id="city" name="city" placeholder="Enter location or city" required>
                        </div>
                        <div class="col-sm-auto">
                            <label class="" for="range">Range :</label>
                        </div>
                        <div class="col-sm-auto">
                            <input class="form-control" type="text" value="" id="range" name="range" placeholder="Enter Range" required>
                        </div>
                        

                        <div class="col-sm-auto">
                            <button type="buttom" class="btn btn-primary w-md" name="submit" onclick="getleadData(this.name, event)"><i class="bx bx-search-alt-2 font-size-14"></i>
                                Search</button>
                        </div>
                    </div>
                </div>
            </form>                                 


            <div class="pull-right" style="float:right;margin: 0 10px 5px 0">
                <a href="<?php echo e(url('/addForm')); ?>" class="btn btn-info" role="button">Add</a>
            </div>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Flag Image</th>
                        <th scope="col">Country</th>
                        <th scope="col">City</th>
                        <th scope="col">Start IP</th>
                        <th scope="col">End IP</th>
                        <th scope="col">Created At</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody id="first_tbody">
                    <?php $i = 1;?>
                    <?php $__currentLoopData = $userData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($i); ?></th>
                        <td><img src="<?php echo e('/flags/' . $user->mst_flag_image); ?>" alt="Example Image" width="100" height="100"></td>
                        <td><?php echo e($user->mst_country_name); ?></td>
                        <td><?php echo e($user->mst_city_name); ?></td>
                        <td><?php echo e($user->sec_start_ip); ?></td>
                        <td><?php echo e($user->sec_end_ip); ?></td>
                        <td><?php echo e(date("d-m-Y H:i:s", strtotime($user->mst_created_at))); ?></td>
                        <td><a href="<?php echo e(url('/updateForm')); ?>?id=<?php echo e($user->mst_id); ?>">Edit</a>&nbsp;&nbsp;<a href="#" class="delete-link" data-id="<?php echo e($user->mst_id); ?>">Delete</a></td>
                    </tr>
                    <?php $i++;?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
            <script>
                                $(document).ready(function () {
                                    // Attach click event to delete links
                                   $('#first_tbody').on('click', '.delete-link', function(e) {
                                        e.preventDefault();
                                        alert('hii');
                                        // Get the user ID from the data-id attribute
                                        var userId = $(this).data('id');

                                        // Display confirmation dialog
                                        var isConfirmed = confirm("Are you sure you want to delete this master?");

                                        // If user confirms, navigate to the delete URL
                                        if (isConfirmed) {
                                            window.location.href = "<?php echo e(url('/deleteData')); ?>?id=" + userId;
                                        }
                                    });
                                });

                                function getleadData(name, event) {
                                    event.preventDefault();
                                    var range = $('#range').val();
                                    var city = $('#city').val();
                                    $.ajaxSetup({
                                        headers: {
                                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                                        }
                                    });

                                    $.ajax({
                                        type: 'POST',
                                        url: "<?php echo e(url('/ipsearch')); ?>",
                                        data: {range: range,
                                            city: city},
                                        success: function (response) {
                                            console.log(response);
                                            $('#first_tbody').html("");
                                            var sl_no = 1;
                                            $.each(response, function (key, item) {
                                                $("#first_tbody").append('<tr>\
                                            <td align="center">' + sl_no + '</td>\
                                            <td><img src="flags/' + item.mst_flag_image + '" alt="Flag Image" width="100" height="100"></td>\
                                            <td class="primary-color">' + item.mst_country_name + '</td>\
                                            <td>' + item.mst_city_name + '</td>\
                                            <td>' + item.sec_start_ip + '</td>\
                                            <td>' + item.sec_end_ip + '</td>\
                                            <td>' + item.mst_created_at + '</td>\
                                            <td><a href="<?php echo e(url('updateForm')); ?>?id=' + item.mst_id + '">Edit</a>&nbsp;&nbsp;<a href="#" class="delete-link" data-id="' + item.mst_id + '">Delete</a></td>\
                                        </tr>');
                                                sl_no++;
                                            });
                                        }
                                    });
                                }
            </script>
        </div>
    </body>
</html><?php /**PATH D:\webguru\webguru\resources\views//master.blade.php ENDPATH**/ ?>