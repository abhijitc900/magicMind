<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Todo List</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <meta name="csrf-token" content="{{ csrf_token() }}">
</head>

<body>
    @include("layout/header-top")
    <div class="my-container">
        <h1>Todo List</h1>
        @if(session('success'))
        <div class="alert-success">
            {{ session('success') }}
        </div>
        @endif

        @if(session('failed'))
        <div class="alert-danger">
            {{ session('failed') }}
        </div>
        @endif


        <div class="pull-right" style="float:right;margin: 0 10px 5px 0">
            <a href="{{ url('/addForm') }}" class="btn btn-info" role="button">Add</a>
        </div>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Date</th>
                    <th scope="col">Title</th>
                    <th scope="col">Description</th>
                    <th scope="col">Created At</th>
                    <th scope="col">Mark Complete</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody id="first_tbody">
                @php $i = 1;@endphp
                @foreach($userData as $user)
                <tr>
                    <th scope="row">{{ $i }}</th>
                    <td>{{ date("d-m-Y", strtotime($user->todo_date)) }}</td>
                    <td>{{ $user->todo_title }}</td>
                    <td>{{ $user->todo_details }}</td>
                    <td>{{ date("d-m-Y H:i:s", strtotime($user->todo_created_at)) }}</td>
                    <td><input type="checkbox" name="to_do" id="to_do" value="{{ $user->todo_id }}" onchange="completeTodo(this.value)" {{  $user->todo_complete === 1 ? "checked" : "" }}></td>
                    <td><a href="{{ url('/updateForm') }}?id={{ $user->todo_id }}">Edit</a>&nbsp;&nbsp;<a href="#" class="delete-link" data-id="{{ $user->todo_id }}">Delete</a></td>
                </tr>
                @php $i++;@endphp
                @endforeach
            </tbody>
        </table>
        <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
        <script>
            $(document).ready(function() {
                // Attach click event to delete links
                $('#first_tbody').on('click', '.delete-link', function(e) {
                    e.preventDefault();
                    // Get the user ID from the data-id attribute
                    var userId = $(this).data('id');

                    // Display confirmation dialog
                    var isConfirmed = confirm("Are you sure you want to delete this todo?");

                    // If user confirms, navigate to the delete URL
                    if (isConfirmed) {
                        window.location.href = "{{ url('/deleteData') }}?id=" + userId;
                    }
                });
            });

            function completeTodo(val) {

                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });

                $.ajax({
                    type: 'POST',
                    url: "{{ url('/completeTodo') }}",
                    data: {
                        todo_id: val

                    },
                    success: function(response) {
                        alert(response.success);
                    }
                });
            }
        </script>
    </div>
</body>

</html>