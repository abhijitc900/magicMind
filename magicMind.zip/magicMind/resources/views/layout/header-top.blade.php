<div class="top-menu" style="background-color:#17a2b8; padding: 20px;">
    <div class="row">
        <div class="col-md-10">
            <a href="{{ url('/dashboard') }}"><img src="/logo.svg" alt="Logo" width="100" height="50" /></a>&nbsp;&nbsp;
            <a href="{{ url('/dashboard') }}" style="color: #fff; font-weight:bold;">Dashboard</a>&nbsp;&nbsp;
            <a href="{{ url('/todo') }}" style="color: #fff; font-weight:bold;">TODO</a>&nbsp;&nbsp;
        </div>
        <div class="col-md-2"> <a href="{{ url('/logout') }}" style="color: #fff; font-weight:bold;">Logout</a></div>
    </div>
</div>